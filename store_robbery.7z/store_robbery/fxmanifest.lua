fx_version 'cerulean'
game 'gta5'

author 'AtlazMC'
description 'Script de Robos de Tiendas'
version '1.0.0'

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}   'config/nconfig.lua'

files {
    'html/notification.html',
    'sounds/alarm.ogg'
}

html 'html/ui.html'

sounds 'alarm.ogg' 'sounds'
