-- server.lua

local QBCore = exports['qb-core']:GetCoreObject()

local robberyCooldown = {}
local storeCooldown = {}
local maxRobberyAmount = 55000
local storeRobberyCooldown = 2 * 60 * 60 * 1000 -- 2 horas en milisegundos
local playerRobberyCooldown = 60 * 60 * 1000 -- 1 hora en milisegundos

RegisterNetEvent('robbery:attemptRobbery', function(storeId)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    local currentTime = os.time() * 1000

    if storeCooldown[storeId] and (currentTime - storeCooldown[storeId]) < storeRobberyCooldown then
        TriggerClientEvent('QBCore:Notify', src, 'La tienda fue robada recientemente, espera un poco.', 'error')
        return
    end

    if robberyCooldown[src] and (currentTime - robberyCooldown[src]) < playerRobberyCooldown then
        TriggerClientEvent('QBCore:Notify', src, 'Aún no puedes robar otra tienda.', 'error')
        return
    end

    storeCooldown[storeId] = currentTime
    robberyCooldown[src] = currentTime

    -- Notify the police about the robbery
    TriggerEvent('police:notifyRobbery', src, storeId)
    
    -- Send robbery data to the client
    TriggerClientEvent('robbery:startRobbery', src, storeId, maxRobberyAmount)
end)

RegisterNetEvent('robbery:completeRobbery', function(storeId, amount)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)

    if player then
        if amount > maxRobberyAmount then
            amount = maxRobberyAmount
        end

        player.Functions.AddMoney('cash', amount)
        TriggerClientEvent('QBCore:Notify', src, 'Has recibido $' .. amount, 'success')
    end
end)

