-- npc_config.lua

-- Define store NPCs here
local storeNPCs = {
    {id = 1, x = 24.4274, y = -1345.5254, z = 29.4970}, -- Example coordinates
    -- Add more NPC configurations as needed
}

-- Spawn NPCs on resource start
AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        for _, npc in ipairs(storeNPCs) do
            local ped = CreatePed(4, `mp_m_shopkeep_01`, npc.x, npc.y, npc.z, 0.0, true, true)
            -- Additional NPC settings if necessary
        end
    end
end)
