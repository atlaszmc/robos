-- Server-side script for handling shoplifting

local storeCooldowns = {} -- Store cooldowns to track last robbery times

-- Store locations and details
local stores = {
    liquorStore = { name = "Liquor Store", coords = vector3(1135.0, -982.0, 46.4) },
    market = { name = "Market", coords = vector3(-303.1, 6213.3, 31.4) },
    tattooShop = { name = "Tattoo Shop", coords = vector3(-1153.5, -1425.5, 4.9) },
    gasStation = { name = "Gas Station", coords = vector3(49.4, -1758.4, 29.6) },
    pharmacy = { name = "Pharmacy", coords = vector3(312.3, -593.7, 43.3) },
    jewelryStore = { name = "Jewelry Store", coords = vector3(-630.0, -239.0, 38.1) },
    clothingStore = { name = "Clothing Store", coords = vector3(75.0, -1392.0, 29.4) },
    barberShop = { name = "Barber Shop", coords = vector3(-814.5, -183.5, 36.6) }
}

-- Function to check if a store is available for robbery
function isStoreAvailable(storeName)
    local lastRobbed = storeCooldowns[storeName]
    if lastRobbed then
        local timeSinceLastRobbery = os.time() - lastRobbed
        return timeSinceLastRobbery > (60 * 60) -- 1 hour cooldown
    end
    return true
end

-- Function to set store cooldown
function setStoreCooldown(storeName)
    storeCooldowns[storeName] = os.time() -- Set current time as last robbery time
end

-- Event to start a robbery
RegisterNetEvent('shoplifting:startRobbery')
AddEventHandler('shoplifting:startRobbery', function(storeName)
    local src = source
    if isStoreAvailable(storeName) then
        -- Notify the police
        TriggerClientEvent('shoplifting:notifyPolice', -1, storeName, src)

        -- Set store cooldown
        setStoreCooldown(storeName)

        -- Give money to the player over time
        TriggerClientEvent('shoplifting:startMoneyCollection', src, storeName)
    else
        TriggerClientEvent('shoplifting:storeUnavailable', src)
    end
end)






