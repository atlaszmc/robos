-- client.lua

local QBCore = exports['qb-core']:GetCoreObject()
local robberyActive = false
local storeRobberyData = {}

RegisterNetEvent('robbery:startRobbery', function(storeId, maxAmount)
    robberyActive = true
    storeRobberyData.storeId = storeId
    storeRobberyData.maxAmount = maxAmount
    storeRobberyData.currentAmount = 0

    -- Trigger alarm sound
    TriggerEvent('playAlarmSound')

    -- Show robbery animation and UI
    TriggerEvent('showRobberyAnimation')
end)

RegisterNetEvent('robbery:completeRobbery', function()
    robberyActive = false
    -- Notify the server of completed robbery
    TriggerServerEvent('robbery:completeRobbery', storeRobberyData.storeId, storeRobberyData.currentAmount)
end)

AddEventHandler('onNPCTargeted', function()
    if robberyActive then
        -- Show amount and robbing player name above NPC's head
        TriggerEvent('showRobberyInfo', storeRobberyData.currentAmount)
        
        -- Increase the amount robbed
        storeRobberyData.currentAmount = storeRobberyData.currentAmount + 1050
        if storeRobberyData.currentAmount >= storeRobberyData.maxAmount then
            storeRobberyData.currentAmount = storeRobberyData.maxAmount
            TriggerEvent('robbery:completeRobbery')
        end
    end
end)

RegisterNetEvent('playAlarmSound', function()
    SendNUIMessage({action = 'playSound', sound = 'alarm'})
end)

RegisterNetEvent('showRobberyAnimation', function()
    -- Implement the robbery animation here
end)

RegisterNetEvent('showRobberyInfo', function(amount)
    local playerName = GetPlayerName(PlayerId())
    -- Implement showing text above NPC here
end)
