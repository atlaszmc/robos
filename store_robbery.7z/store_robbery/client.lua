-- Client-side script for handling shoplifting

local npcModels = {
    liquorStore = "mp_m_shopkeep_01",
    market = "mp_m_shopkeep_01",
    tattooShop = "mp_m_shopkeep_01",
    gasStation = "mp_m_shopkeep_01",
    pharmacy = "mp_m_shopkeep_01",
    jewelryStore = "mp_m_shopkeep_01",
    clothingStore = "mp_m_shopkeep_01",
    barberShop = "mp_m_shopkeep_01"
}

-- Function to load NPC model
function loadModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(500)
    end
end

-- Function to create an NPC
function createNPC(storeName)
    local model = npcModels[storeName]
    local coords = stores[storeName].coords
    loadModel(model)

    local npcPed = CreatePed(4, model, coords, 0.0, false, true)
    SetPedAsEnemy(npcPed, false)
    SetPedCanRagdoll(npcPed, false)
    SetPedCanRagdollFromPlayerImpact(npcPed, false)
    SetPedConfigFlag(npcPed, 281, true)
    SetPedCanBeTargetted(npcPed, false)
    TaskStartScenarioInPlace(npcPed, "WORLD_HUMAN_STAND_MOBILE", 0, true)
end

-- Event to notify police
RegisterNetEvent('shoplifting:notifyPolice')
AddEventHandler('shoplifting:notifyPolice', function(storeName, playerId)
    TriggerEvent('qb:notifyPolice', storeName, playerId)
end)

-- Event to start money collection
RegisterNetEvent('shoplifting:startMoneyCollection')
AddEventHandler('shoplifting:startMoneyCollection', function(storeName)
    local totalAmount = 55000
    local amountPerTick = 1050
    local ticks = totalAmount / amountPerTick
    local playerPed = PlayerPedId()
    local startTime = GetGameTimer()
    local endTime = startTime + (5 * 60 * 1000) -- 5 minutes in milliseconds

    -- Collect money over time
    Citizen.CreateThread(function()
        while GetGameTimer() < endTime do
            Citizen.Wait(1000)
            if IsPedArmed(playerPed, 7) then
                -- Simulate NPC giving money
                TriggerEvent('chat:addMessage', {
                    color = { 255, 0, 0 },
                    multiline = true,
                    args = { "NPC", "You received $" .. amountPerTick .. " from the NPC." }
                })
            else
                break
            end
        end
    end)
end)

-- Event to notify if the store is unavailable
RegisterNetEvent('shoplifting:storeUnavailable')
AddEventHandler('shoplifting:storeUnavailable', function()
    TriggerEvent('chat:addMessage', {
        color = { 255, 0, 0 },
        multiline = true,
        args = { "System", "This store has been robbed recently and is currently unavailable." }
    })
end)

-- Event to handle NPC behavior when threatened
RegisterNetEvent('shoplifting:handleThreat')
AddEventHandler('shoplifting:handleThreat', function()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    -- Check if a firearm is pointed at the NPC
    if IsPedArmed(playerPed, 7) then
        -- NPC raises hands
        local npcPed = PlayerPedId()
        TaskStartScenarioInPlace(npcPed, "WORLD_HUMAN_STAND_MOBILE", 0, true)
        -- Activate alarm (this can be expanded as needed)
        TriggerEvent('chat:addMessage', {
            color = { 255, 0, 0 },
            multiline = true,
            args = { "Alarm", "The alarm has been activated!" }
        })
    end
end)
